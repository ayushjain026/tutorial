import configuration from "../Configurations/configuration"
import Axios from "./AxiosService"

const axios = new Axios();
// const config = new configuration(); 

export default class crudServices {

    CreateRecord(data){
        console.log("data : ", data, " Url : ", configuration.createCountryRecords)
        return axios.postData(configuration.createCountryRecords, data, false)
    }

    GetRecord(){
        console.log("Url : " + configuration.getCountryRecords);
        return axios.getData(configuration.getCountryRecords, false)
    }

    GetCountryData(id){
        console.log("Id: ", id,"Url : ", configuration.getCountryRecord+id)
        return axios.getData(configuration.getCountryRecord+id, false)
    }

    UpdateCountry(data){
        console.log("Updating user")
        return axios.putData(configuration.updateCountryRecord, data, false)
    }

    deleteCountry(id){
        console.log("In delete Country Event")
        return axios.deleteData(configuration.deleteCountryRecord, id, false)
    }

}
