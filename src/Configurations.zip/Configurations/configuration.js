module.exports = {
    getCountryRecords : "https://localhost:7163/api/Country/country_data",
    createCountryRecord : "https://localhost:7163/api/Country",
    getCountryRecord : "https://localhost:7163/api/Country?Id=",
    updateCountryRecord: "https://localhost:7163/api/Country",
    deleteCountryRecord: "https://localhost:7163/api/Country"
}