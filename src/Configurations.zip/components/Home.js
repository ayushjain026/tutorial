import React from 'react'

export default function home() {
  return (
    <h1 className='text-center'>Home</h1>
  )
}
